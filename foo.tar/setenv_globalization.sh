export GAAS_API_KEY=420173ac-3237-4a5f-88f9-074f6d11871a
export GAAS_ENDPOINT=https://gaas.mybluemix.net/translate
export GAAS_DASHBOARD=https://gaas-dashboard.mybluemix.net/overview.wss?instance_id=4cfe1f04-634d-4030-baf4-08e4865a4b44&space_id=7ab89e09-ef4d-4820-8653-de5fc06752c8
